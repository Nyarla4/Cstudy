#include<iostream>
#include<string>
using namespace std;

class GraphicEditor
{
	GraphicEditor*next;
public:
	virtual void getName() = 0;
	GraphicEditor() { next = NULL; }
	virtual ~GraphicEditor() {}
	GraphicEditor*add(GraphicEditor*p)
	{
		this->next = p;
		return p;
	}
	GraphicEditor*getNext()
	{
		return next;
	}
};

class Line:public GraphicEditor
{
public:
	virtual void getName()
	{
		cout << "Line";
	}
};

class Circle :public GraphicEditor
{
public:
	virtual void getName()
	{
		cout << "Circle";
	}
};

class Rect :public GraphicEditor
{
public:
	virtual void getName() 
	{
		cout << "Rectangle";
	}
};

class UI
{
	GraphicEditor*pStart = NULL;
	GraphicEditor*pLast;
	int chk;
	int showCnt = 0;
public:
	void input(int* chk)
	{
		cout << "����:1, ����:2, ��κ���:3, ����:4 >>";
		cin >> *chk;
	}
	void create()
	{
		cout << "��:1, ��:2, �簢��:3 >>";
		cin >> chk;
		switch (chk)
		{
		case 1:
			if (pStart == NULL)
			{
				pStart = new Line();
				pLast = pStart;
			}
			else
				pLast = pLast->add(new Line());
			break;
		case 2:
			if (pStart == NULL)
			{
				pStart = new Circle();
				pLast = pStart;
			}
			else
				pLast = pLast->add(new Circle());
			break;
		case 3:
			if (pStart == NULL)
			{
				pStart = new Rect();
				pLast = pStart;
			}
			else
				pLast = pLast->add(new Rect());
			break;
		default:
			break;
		}
	}
	void del()
	{
		cout << "�����ϰ��� �ϴ� ������ �ε��� >>";
		cin >> chk;
		int chkp = 0;
		GraphicEditor*p = pStart;
		GraphicEditor*q;
		while (p != NULL)
		{
			q = p->getNext();
			if (chk == chkp)
				delete p;
			p = q;
			chkp++;

		}
		delete p;
	}
	void show()
	{
		GraphicEditor*p = pStart;
		while (p != NULL)
		{
			cout << showCnt << ": ";
			p->getName();
			cout << endl;
			p = p->getNext();
			showCnt++;
		}
		showCnt = 0;
	}
};

int main()
{
	UI ui;
	int chk = 0;
	int *chkp = &chk;
	cout << "�׷��� �������Դϴ�" << endl;
	while (*chkp != 4)
	{
		ui.input(chkp);
		switch (*chkp)
		{
		case 1:
			ui.create();
			break;
		case 2:
			ui.del();
			break;
		case 3:
			ui.show();
			break;
		default:
			break;
		}
	}
	return 0;
}