
// ChildView.cpp : CChildView Ŭ������ ����
//

#include "stdafx.h"
#include "HW4.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	anime = false;
	src = false;
	chk = 0;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_WM_CREATE()
	ON_WM_HSCROLL()
	ON_BN_CLICKED(101, OnStarted)
	ON_BN_CLICKED(102, OnPaused)
	ON_BN_CLICKED(103, OnSaved)
	ON_BN_CLICKED(104, OnLoaded)
	ON_BN_CLICKED(105, OnCleared)
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
END_MESSAGE_MAP()



// CChildView �޽��� ó����

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this);

	CRect rect;
	GetClientRect(rect);
	CDC memdc; // ���� DC
	memdc.CreateCompatibleDC(&dc);	CBitmap bitmap; // �׸��� ������ ���� ����
	bitmap.CreateCompatibleBitmap(&dc, rect.Width(), rect.Height());
	memdc.SelectObject(&bitmap);
	POSITION posShape,posLine,posChk;
	posShape = ptShape.GetHeadPosition();	posLine = ptLine.GetHeadPosition();	posChk = rectChk.GetHeadPosition();
	CPen penL(PS_SOLID, 1, RGB(0, 0, 0)),penD(PS_DASH, 1, RGB(0, 0, 0)), penR(PS_SOLID,1,RGB(255,0,0)), penB(PS_SOLID, 1, RGB(0, 0, 0));
	CBrush bru(RGB(255, 255, 255));
	memdc.SelectObject(bru);
	memdc.Rectangle(rect);
	while (posLine != NULL)
	{
		if (anime)
			memdc.SelectObject(penD);
		else
			memdc.SelectObject(penL);
		
		if (posLine == ptLine.GetHeadPosition())
			memdc.MoveTo(ptLine.GetNext(posLine));
		else
			memdc.LineTo(ptLine.GetNext(posLine));
	}
	if (!anime)
	{
		while (posShape != NULL)
		{
			if (src)
			{
				if (posShape == posOtherShape)
					memdc.SelectObject(&penR);
				else
					memdc.SelectObject(&penB);
			}
			else
			{
				if (posShape == ptShape.GetTailPosition())
					memdc.SelectObject(&penR);
				else
					memdc.SelectObject(&penB);
			}
			if (rectChk.GetNext(posChk))
				memdc.Rectangle(ptShape.GetNext(posShape).x - 20, ptShape.GetAt(posShape).y - 20, ptShape.GetAt(posShape).x + 20, ptShape.GetAt(posShape).y + 20);
			else
				memdc.Ellipse(ptShape.GetNext(posShape).x - 20, ptShape.GetAt(posShape).y - 20, ptShape.GetAt(posShape).x + 20, ptShape.GetAt(posShape).y + 20);
		}
	}
	else
	{
		memdc.SelectObject(penL);
		memdc.Rectangle(animeShape.x - 20, animeShape.y - 20, animeShape.x + 20, animeShape.y + 20);
	}
	dc.BitBlt(0, 0, rect.Width(), rect.Height(), &memdc, 0, 0, SRCCOPY);
}



void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if (!anime)
	{
		src = false;
		rectChk.AddTail(true);
		ptShape.AddTail(point);
		ptLine.AddTail(point);
		scroll.SetScrollRange(1, ptShape.GetSize());
		scroll.SetScrollPos(1);
	}
	Invalidate();
	CWnd::OnLButtonDown(nFlags, point);
}


void CChildView::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
		if (!anime)	{
		src = false;
		rectChk.AddTail(false);
		ptShape.AddTail(point);
		ptLine.AddTail(point);
		scroll.SetScrollRange(1, ptShape.GetSize());
		scroll.SetScrollPos(1);
	}
	Invalidate();

	CWnd::OnRButtonDown(nFlags, point);
}


int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	playB.Create(_T(">"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		CRect(0, 0, 80, 30), this, 101);
	pauseB.Create(_T("||"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		CRect(80, 0, 160, 30), this, 102);

	saveB.Create(_T("SAVE"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		CRect(160, 0, 240, 30), this, 103);
	loadB.Create(_T("LOAD"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		CRect(240, 0, 320, 30), this, 104);

	clearB.Create(_T("CLEAR"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		CRect(320, 0, 400, 30), this, 105);

	scroll.Create(SBS_HORZ, CRect(400, 0, 800, 30), this, 106);
	scroll.ShowWindow(true);
	
	SetTimer(0, 30, NULL);

	return 0;
}


void CChildView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if (!anime)
	{
		if (pScrollBar != NULL) {
			if (pScrollBar->GetSafeHwnd() == scroll.GetSafeHwnd())
			{
				if (!src)
				{
					src = true;
					posOtherShape = ptShape.GetHeadPosition();
				}
				npos = pScrollBar->GetScrollPos();
				chk = npos;
				if (nSBCode == SB_THUMBTRACK || nSBCode == SB_THUMBPOSITION)
				{
					pScrollBar->SetScrollPos(nPos);
					chk -= pScrollBar->GetScrollPos();
					if (chk > 0)
					{
						for (int i = 0; i < chk; i++)
							ptShape.GetPrev(posOtherShape);
					}
					else
					{
						chk *= -1;
						for (int i = 0; i < chk; i++)
							ptShape.GetNext(posOtherShape);
					}
					this->Invalidate();
				}
				if (nSBCode == SB_LINELEFT || nSBCode == SB_LINERIGHT)
				{
					if (nSBCode == SB_LINELEFT)
					{
						if (npos != 1)
							npos--;
					}
					else if (nSBCode == SB_LINERIGHT)
					{
						if (npos != ptShape.GetSize())
							npos++;
					}
					chk -= npos;
					if (chk > 0)
					{
						for (int i = 0; i < chk; i++)
							ptShape.GetPrev(posOtherShape);
					}
					else
					{
						chk *= -1;
						for (int i = 0; i < chk; i++)
							ptShape.GetNext(posOtherShape);
					}
					pScrollBar->SetScrollPos(npos);
				}
			}
		}
	}
	
	Invalidate();
	CWnd::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CChildView::OnStarted()
{
	anime = true;
	src = false;
	scroll.SetScrollRange(1, ptShape.GetSize());
	npos = 1;
	animeShape = ptShape.GetAt(ptShape.GetHeadPosition());
	animePos = ptShape.GetHeadPosition();
	ptShape.GetNext(animePos);
	minx = (animeShape.x - ptShape.GetAt(animePos).x)/10;
	miny = (animeShape.y - ptShape.GetAt(animePos).y)/10;
	Invalidate();
}
void CChildView::OnPaused()
{
	anime = false;
	scroll.SetScrollPos(1);
	src = false;
	Invalidate();
}
void CChildView::OnSaved()
{
	if (!anime)
	{
		CFile file(_T("SaveData.dat"), CFile::modeCreate | CFile::modeWrite);
		CArchive ar(&file, CArchive::store);
		ptShape.Serialize(ar);		ptLine.Serialize(ar);
		rectChk.Serialize(ar);

		src = false;
	}
	Invalidate();
}
void CChildView::OnLoaded()
{
	if (!anime)
	{
		ptShape.RemoveAll();
		ptLine.RemoveAll();
		rectChk.RemoveAll();

		CFile file2;
		CFileException e;
		if (!file2.Open(_T("SaveData.dat"), CFile::modeRead, &e))
		{
			e.ReportError();
			return;
		};

		CArchive ar(&file2, CArchive::load);
		ptShape.Serialize(ar);		ptLine.Serialize(ar);
		rectChk.Serialize(ar);

		scroll.SetScrollRange(1, ptShape.GetSize());
		src = false;
	}
	Invalidate();
}
void CChildView::OnCleared()
{
	if (!anime)
	{
		ptShape.RemoveAll();
		ptLine.RemoveAll();
		rectChk.RemoveAll();

		src = false;
	}
	Invalidate();
}

void CChildView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if (anime)
	{
		if (nIDEvent == 0)
		{
			if (minx < 0)
			{
				if (animeShape.x - ptShape.GetAt(animePos).x > 0)
					animeShape.x = ptShape.GetAt(animePos).x;
			}
			else
			{
				if (animeShape.x - ptShape.GetAt(animePos).x < 0)
					animeShape.x = ptShape.GetAt(animePos).x;
			}
			if(miny<0)
			{
				if (animeShape.y - ptShape.GetAt(animePos).y > 0)
					animeShape.y = ptShape.GetAt(animePos).y;
			}
			else
			{
				if (animeShape.y - ptShape.GetAt(animePos).y < 0)
					animeShape.y = ptShape.GetAt(animePos).y;
			}
				if (animeShape != ptShape.GetAt(animePos))
				{
					animeShape.x -= minx;
					animeShape.y -= miny;
					
				}
				else if (animeShape == ptShape.GetAt(animePos))
				{
					npos++;
					ptShape.GetNext(animePos);
					if (animeShape == ptShape.GetAt(ptShape.GetTailPosition()))
					{
						scroll.SetScrollPos(ptShape.GetSize());
						animePos = ptShape.GetHeadPosition();
						minx = (animeShape.x - ptShape.GetAt(animePos).x);
						miny = (animeShape.y - ptShape.GetAt(animePos).y);
					}
					if (npos > ptShape.GetSize())
						npos = 1;
					if (animeShape != ptShape.GetAt(ptShape.GetTailPosition()))
					{
						minx = (animeShape.x - ptShape.GetAt(animePos).x) / 10;
						miny = (animeShape.y - ptShape.GetAt(animePos).y) / 10;
					}
				}
				scroll.SetScrollPos(npos);
		}
		Invalidate();
	}
	CWnd::OnTimer(nIDEvent);
}


BOOL CChildView::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	return true;// CWnd::OnEraseBkgnd(pDC);
}
