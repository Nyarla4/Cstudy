
// ChildView.h : CChildView Ŭ������ �������̽�
//


#pragma once


// CChildView â

class CChildView : public CWnd
{
// �����Դϴ�.
public:
	CChildView();

// Ư���Դϴ�.
public:
	CList<CPoint>ptShape;
	CList<bool>rectChk;
	CList<CPoint>ptLine;
	CButton saveB, loadB;
	CButton playB, pauseB;
	CButton clearB;
	bool anime;
	CScrollBar scroll;
	int npos;
	bool src;
	int chk;
	POSITION posOtherShape;
	CPoint animeShape;
	POSITION animePos;
	double minx, miny;
// �۾��Դϴ�.
public:

// �������Դϴ�.
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// �����Դϴ�.
public:
	virtual ~CChildView();

	// ������ �޽��� �� �Լ�
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnStarted();
	afx_msg void OnPaused();
	afx_msg void OnSaved();
	afx_msg void OnLoaded();
	afx_msg void OnCleared();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
};

